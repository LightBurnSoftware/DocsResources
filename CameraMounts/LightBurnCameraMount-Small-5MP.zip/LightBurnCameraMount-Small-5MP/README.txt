This is a 3D printed enclosure for the LightBurn 5MP camera and smaller 8MP cameras (120 and 75 degree), based on an original design by Neil Rosenberg.

Ours has been designed to better fit all the smaller cameras we sell, and includes a small interior lip to prevent the camera from sliding. The mount is made to attach to the inside of the lid with 3M double-sided VHB tape. The camera angle is easily adjusted by loosening the knobs on either side of the mount, and the face plate is held in place by tension clips.

For assembly, you'll need two m5x15 screws and two m5 nuts, as well as strong mounting tape (we recommend 3M double-sided VHB tape) for mounting to the lid.

You can find the original at https://www.thingiverse.com/thing:3891092 or https://www.printables.com/model/439724-lightburn-camera-mount